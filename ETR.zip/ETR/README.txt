Texture credits go to

benjee10 - sofi

Zorg- lower tank texture

other credits

Lennon/Kerbalboi/@lsam_5 - the texture kitbasher

---------------------------------------------------------

INSTALATION

1: put any folders in Gamedata in you Gamedata folder

2: Allow for it to overwrite anything

3: enjoy!

----------------------------------------------------------

 THIS IS A BETA VERSION YOU CANNOT SEND THIS TO ANYONE WITHOUT PERMISSION also don't be a jerk and steal it i will find you and i will send you angry dms 